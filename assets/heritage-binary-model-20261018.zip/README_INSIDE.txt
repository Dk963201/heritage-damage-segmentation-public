HERITAGE BINARY CRACK MODEL - 18 OCTOBER 2026

Extract into a NEW project checkout, preserving paths. Do not overwrite an
existing experiment or user annotations. This archive contains the final
U-Net / EfficientNet-B0 binary crack state dictionary, protocol and results.
It contains no source photos, public replay pool, four-class model or severity model.

With the project dependencies installed and a local image available, run:
python project.py predict-cracks --checkpoint local-results/reviewed-replay-long-v1/unet-reviewed-replay-long-final.pt --image wall.jpg --output local-results/new-wall-prediction

Default inference: native 512-pixel tiles, threshold 0.5. Outputs are visual crack
candidates, not human labels or structural-safety decisions. The stored 69.23%
pooled crack Dice belongs to three development holdout models, NOT an independent
test of this final all-three-photo checkpoint. The final model trained on all
three reviewed Erbil photos. There is no verified Amedi, four-class or severity
accuracy. Repeated development selection and sparse labels limit generalization.
No 80% achievement is claimed.

This is an inference download, not a complete training-reproduction bundle. The
original protocol references additional photos, initialization weights, public
training data and replay inputs not included here. See the asset documentation.
