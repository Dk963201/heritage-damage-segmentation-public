REVIEWED BINARY LABELS AND EVIDENCE - 18 OCTOBER 2026

Extract into a NEW project checkout, preserving paths. Do not overwrite existing
annotations. This archive contains three exact frozen native-resolution masks,
44 original batch review manifests, the separate accepted region 30 correction,
a derived acceptance ledger, and historical results/verification records.
It contains no source photographs or new annotations.

Open local-results/reviewed-through-333/acceptance-ledger-export.json for accepted
IDs 1-333 and pending IDs 334-336. Acceptance refers only to displayed binary pixels.
Original approved:false flags are retained; do not convert these into full-image,
expert or four-class approval. Superseded proposals and final accepted correction
evidence are distinguished in the ledger. Original records are unmodified.

Mask encoding: 0 = reviewed intact/non-crack; 1 = reviewed crack; 255 = ignore.
Unselected pixels are NOT automatically healthy. Pending 334-336 remain ignored.
These are three Erbil photos, not 333 independent photos. No approved four-class
masks or image-level severity grades are included.

Source photos are distributed separately in the candidate archives:
0450: heritage-versions-06.zip, images/0450.jpg, attribution/0450.json
0650: heritage-versions-09.zip, images/0650.jpg, attribution/0650.json
0750: heritage-versions-10.zip, images/0750.jpg, attribution/0750.json
Preserve photographer attribution/license. Source hashes and expected local
paths are in the ledger; those photos are not in this archive.

Frozen mask snapshots are authoritative. Historical review JSON references prior
masks/selection images not included here. Results record development experiments,
not new independent accuracy. Fold weights, out-of-fold probability arrays and
public training data are absent, so this archive alone cannot rerun the whole
experiment or recompute every metric.
